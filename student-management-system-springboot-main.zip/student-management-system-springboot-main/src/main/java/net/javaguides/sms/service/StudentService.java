package net.javaguides.sms.service;

import java.util.List;

//import net.javaguides.sms.entity.Student;
import net.javaguides.sms.entity.Vehicle;

public interface StudentService {
	List<Vehicle> getAllStudents();
	
	Vehicle saveStudent(Vehicle student);
	
	Vehicle getStudentById(Long id);
	
	Vehicle updateStudent(Vehicle student);
	
	void deleteStudentById(Long id);
}
